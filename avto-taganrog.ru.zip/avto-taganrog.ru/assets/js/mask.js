// Маска для телефона
document.addEventListener('DOMContentLoaded', function () {
  const phoneInput = document.getElementById('phone-input');
  if (!phoneInput) {
    console.warn('Не найдено поле #phone-input');
    return;
  }

  if (typeof IMask === 'undefined') {
    console.error('IMask не загружен. Проверьте подключение https://unpkg.com/imask');
    return;
  }

  IMask(phoneInput, {
    mask: '+7 (000) 000-00-00'
  });
});
