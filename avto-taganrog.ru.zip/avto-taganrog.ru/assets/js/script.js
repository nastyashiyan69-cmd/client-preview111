// === Глобальные переменные ===
const totalSteps = 6;
let currentStep = 1;

// === DOMContentLoaded: безопасная инициализация ===
document.addEventListener('DOMContentLoaded', function () {
  const welcomeScreen = document.getElementById('welcome-screen');
  const quizContainer = document.getElementById('quiz-container');
  const feedbackForm = document.getElementById('feedback-form');
  const progressContainer = document.getElementById('progress-container');

  if (welcomeScreen) welcomeScreen.style.display = 'block';
  if (quizContainer) quizContainer.style.display = 'none';
  if (feedbackForm) feedbackForm.style.display = 'none';
  if (progressContainer) progressContainer.style.display = 'none';

  // === Инициализация модулей ===
  initPhoneMask();
  initFormSubmit();
  initRadioSelection();
  initAutoNext();
  setupModals();
});

// === Автоматический переход с ветвлением ===
function initAutoNext() {
  document.querySelectorAll('input[type="radio"]').forEach(radio => {
    radio.addEventListener('change', function () {
      const name = this.name;

      if (name === 'q1') {
        const selectedValue = this.value;

        setTimeout(() => {
          const step1 = document.getElementById('step-1');
          if (step1) {
            step1.style.display = 'none';
            step1.classList.remove('active');
          }

          let nextStepId;
          if (selectedValue === 'Lada (ВАЗ)') {
            nextStepId = 'step-2-lada';
            currentStep = 2;
          } else if (selectedValue === 'Belgee') {
            nextStepId = 'step-2-belgee';
            currentStep = 2;
          } else {
            nextStepId = 'step-3';
            currentStep = 3;
          }

          const nextStep = document.getElementById(nextStepId);
          if (nextStep) {
            nextStep.style.display = 'block';
            setTimeout(() => nextStep.classList.add('active'), 50);
            updateProgress();
          }
        }, 400);

      } else if (name === 'q2_lada' || name === 'q2_belgee') {
        setTimeout(() => {
          const currentId = this.closest('.step').id;
          const currentEl = document.getElementById(currentId);
          if (currentEl) {
            currentEl.style.display = 'none';
            currentEl.classList.remove('active');
          }

          const step3 = document.getElementById('step-3');
          if (step3) {
            step3.style.display = 'block';
            setTimeout(() => step3.classList.add('active'), 50);
            currentStep = 3;
            updateProgress();
          }
        }, 400);

      } else if (name === 'q3') {
        setTimeout(() => {
          hideCurrentAndShow('step-3', 'step-4');
          currentStep = 4;
          updateProgress();
        }, 400);

      } else if (name === 'q4') {
        setTimeout(() => {
          hideCurrentAndShow('step-4', 'step-5');
          currentStep = 5;
          updateProgress();
        }, 400);

      } else if (name === 'q5') {
        setTimeout(() => {
          hideCurrentAndShow('step-5', null);
          showForm(); // Показываем форму после q5
        }, 400);
      }
    });
  });
}

// Универсальная функция скрытия/показа шагов
function hideCurrentAndShow(currentId, nextId) {
  const current = document.getElementById(currentId);
  if (current) {
    current.style.display = 'none';
    current.classList.remove('active');
  }

  if (nextId) {
    const next = document.getElementById(nextId);
    if (next) {
      next.style.display = 'block';
      setTimeout(() => next.classList.add('active'), 50);
    }
  }
}

// === Подсветка выбранных элементов ===
function initRadioSelection() {
  document.querySelectorAll('.option-img').forEach(label => {
    const radio = label.querySelector('input[type="radio"]');
    if (radio) {
      radio.addEventListener('change', function () {
        document.querySelectorAll('.option-img').forEach(el => {
          el.classList.remove('selected');
        });
        if (this.checked) label.classList.add('selected');
      });
    }
  });

  document.querySelectorAll('.custom-radio-checkbox').forEach(label => {
    const radio = label.querySelector('input[type="radio"]');
    if (radio) {
      radio.addEventListener('change', function () {
        const name = radio.name;
        document.querySelectorAll(`.custom-radio-checkbox input[name="${name}"]`).forEach(r => {
          r.parentElement.classList.toggle('selected', r.checked);
        });
      });
    }
  });
}

// === Маска телефона (imask) ===
function initPhoneMask() {
  const phoneInput = document.getElementById('phone-input');
  if (!phoneInput || typeof IMask === 'undefined') return;

  IMask(phoneInput, { mask: '+7 (000) 000-00-00' });
}

// === Активация кнопки формы + уведомление об успехе ===
function initFormSubmit() {
  const agreeCheckbox = document.getElementById('agree-policy');
  const submitBtn = document.getElementById('submit-btn');
  const form = document.getElementById('contact-form');

  if (!agreeCheckbox || !submitBtn || !form) return;

  // Активация/деактивация кнопки
  agreeCheckbox.addEventListener('change', () => {
    submitBtn.disabled = !agreeCheckbox.checked;
  });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (submitBtn.disabled) return;

    const formData = new FormData(form);
    const data = Object.fromEntries(formData);

    console.log('Форма отправлена:', data);

    // === Меняем содержимое формы на сообщение об успехе ===
    form.innerHTML = `
      <div style="
        text-align: center;
        padding: 40px 20px;
        color: #fff;
        font-size: 18px;
        line-height: 1.6;
      ">
        <div style="
          background-color: rgba(46, 204, 113, 0.2);
          border: 2px solid #2ecc71;
          border-radius: 12px;
          padding: 20px;
          margin-bottom: 20px;
          display: inline-block;
        ">
          ✅
        </div>
        <h3 style="margin: 15px 0; font-weight: bold;">
          Спасибо!
        </h3>
        <p>
          Ваша заявка успешно отправлена.<br>
          Мы свяжемся с вами в течение 10 минут.
        </p>
      </div>
    `;

    // Через 5 секунд закрываем форму и возвращаемся к началу
    setTimeout(() => {
      const feedbackForm = document.getElementById('feedback-form');
      const welcomeScreen = document.getElementById('welcome-screen');

      if (feedbackForm) feedbackForm.style.display = 'none';
      if (welcomeScreen) welcomeScreen.style.display = 'block';

      // Сбрасываем квиз
      currentStep = 1;
      updateProgress();

      window.scrollTo(0, 0);
    }, 5000);
  });
}

// === Показать форму после квиза ===
function showForm() {
  const quizContainer = document.getElementById('quiz-container');
  const feedbackForm = document.getElementById('feedback-form');
  const progressBar = document.getElementById('progress-bar');

  if (quizContainer) quizContainer.style.display = 'none';
  if (feedbackForm) feedbackForm.style.display = 'block';
  if (progressBar) progressBar.style.width = '100%';

  window.scrollTo(0, 0);
}

// === Начать квиз ===
function startQuiz() {
  const welcomeScreen = document.getElementById('welcome-screen');
  const quizContainer = document.getElementById('quiz-container');
  const progressContainer = document.getElementById('progress-container');

  if (welcomeScreen) welcomeScreen.style.display = 'none';
  if (quizContainer) quizContainer.style.display = 'block';
  if (progressContainer) progressContainer.style.display = 'block';

  window.scrollTo(0, 0);
  updateProgress();
}

// === Обновление прогресс-бара ===
function updateProgress() {
  const bar = document.getElementById('progress-bar');
  if (!bar) return;

  const percent = Math.min(100, ((currentStep - 1) / totalSteps) * 100);
  bar.style.width = `${percent}%`;
}

// === Модальные окна ===
function setupModals() {
  const popup = document.getElementById('popup');
  if (popup) {
    popup.addEventListener('click', e => {
      if (e.target === popup) closePopup();
    });
  }

  const policyModal = document.getElementById('policy-modal');
  if (policyModal) {
    policyModal.addEventListener('click', e => {
      if (e.target === policyModal) closePolicy();
    });
  }
}

function openPopup() {
  const popup = document.getElementById('popup');
  if (popup) {
    popup.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  }
}

function closePopup() {
  const popup = document.getElementById('popup');
  if (popup) {
    popup.style.display = 'none';
    document.body.style.overflow = 'auto';
  }
}

function showPolicy() {
  const modal = document.getElementById('policy-modal');
  if (modal) {
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  }
}

function closePolicy() {
  const modal = document.getElementById('policy-modal');
  if (modal) {
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
  }
}
